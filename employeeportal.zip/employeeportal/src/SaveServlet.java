
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SaveServlet")
//@WebServlet(name = "SaveServlet", urlPatterns = { "/SaveServlet" })
public class SaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public SaveServlet() {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String id = request.getParameter("id");
		int id1 = Integer.parseInt(id);
		String name = request.getParameter("name");
		String password = request.getParameter("pass");
		String email = request.getParameter("email");
		String country = request.getParameter("country");

		Employee e = new Employee();
		e.setId(id1);
		e.setName(name);
		e.setPassword(password);
		e.setEmail(email);
		e.setCountry(country);

		int i = EmployeeDao.save(e);
		if (i > 0) {
			out.println("<a href='Index.html'> Add new Employee</a>");
			out.println("<P>Record Has been saved Successfully!! </p>");
		} else {
			out.println("<a href='Index.html'> Add new Employee</a>");
			out.println("Sorry !! Unable to Save the Record");
		}
		out.close();
	}
}
