  

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public EditServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<h1> Update Employee</h1>");
		
		String sid=request.getParameter("id");
		int id = Integer.parseInt(sid);
		
		Employee emp=EmployeeDao.getEmployeeById(id);
		out.println("<body bgcolor='Yellow'>");
		out.print("<form action='EditServlet2' method='get'>");
		out.print("<table>");
		out.print("<tr>"
				+ "<td></td>"
				+ "<td><input type='hidden' name='id' value='"+emp.getId()+"'/> </td> "
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Name :</td>"
				+ "<td><input type='text' name='name' value='"+emp.getName()+"'/> </td> "
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Password : </td>"
				+ "<td><input type='password' name='password' value='"+emp.getPassword()+"'/> </td> "
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Email : </td>"
				+ "<td><input type='email' name='email' value='"+emp.getEmail()+"'/> </td> "
				+ "</tr>");
		
		out.print("<tr><td> Country :</td> <td>");
		out.println("<select name='Country' style='width:150px'>");
		out.println("<option>India</option>");
		out.println("<option>USA</option>");
		out.println("<option>UK</option>");
		out.println("<option>Other</option>");
		out.println("</select>");
		out.println("</td></tr>");
		out.println("<tr><td colspan='2'> <input type='submit' value='edit & save'/> </td></tr>");
	
		out.print("</table>");
		out.print("</form>");
		out.close();
	}

}
