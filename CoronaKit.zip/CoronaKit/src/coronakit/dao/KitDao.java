package coronakit.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;

import coronakit.model.KitDetail;
import coronakit.model.ProductMaster;

public class KitDao {

	private static final String TotalCost = null;

	public static Connection getConnection()

	{
		Connection connection = null;
		try {
//		Class.forName("oracle.jdbc.driver.OracleDriver");
//		connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Srikanth1");
			String jdbcURL = "jdbc:sqlserver://localhost:1433;databaseName=FullStack;user=sa;password=Password1";
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(jdbcURL);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return connection;
	}
	/*
	 * public static int updatesummary(int id,float total) { int status2=0; try {
	 * Connection con = KitDao.getConnection(); String
	 * sql2="update ordersummary set Totalprice=? where itemno=?"; PreparedStatement
	 * ps2 = con.prepareStatement(sql2); ps2.setInt(2,id); ps2.setFloat(1,total);
	 * con.close(); } catch (Exception e) { e.printStackTrace(); } return status2; }
	 */

	/*
	 * public static int summary(int id,String productname,float total) { KitDetail
	 * itemdetails=new KitDetail(); int status1=0; try { Connection con =
	 * KitDao.getConnection();
	 * 
	 * String sql="select * from ordersummary where itemno=?"; PreparedStatement ps
	 * = con.prepareStatement(sql); ps.setInt(1,id); ResultSet rs =
	 * ps.executeQuery();
	 * 
	 * 
	 * 
	 * if(rs.next()==false) { String
	 * sql1="insert into ordersummary(itemno,itemname,Totalprice) values(?,?,?)";
	 * PreparedStatement ps1 = con.prepareStatement(sql1); ps1.setInt(1,id);
	 * ps1.setString(2,productname); ps1.setFloat(3, total);
	 * 
	 * status1=ps1.executeUpdate();
	 * 
	 * con.close(); } else { String
	 * sql2="update ordersummary set Totalprice=? where itemno=?"; PreparedStatement
	 * ps2 = con.prepareStatement(sql2); ps2.setFloat(1,total); ps2.setInt(2,id);
	 * 
	 * }
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } return status1; }
	 */

	public static int addToCart(int id1, String productname, int cost, int quantity1) {
		ProductMaster products = new ProductMaster();
		
		int status=0;
		try {
			Connection con = KitDao.getConnection();

			String sql = "update ProductList set quantity=? where Product_ID=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, quantity1);
			ps.setInt(2, id1);
			status=ps.executeUpdate();
			
			String sql1 = "select sum(total) as TotalCost from ProductList";
			PreparedStatement ps1 = con.prepareStatement(sql1);
			ResultSet rs = ps1.executeQuery();

			while (rs.next()) {
								
				products.setTotalcost(rs.getFloat(TotalCost));
				con.close();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}

	public static List<ProductMaster> getAllProducts() throws SQLException {

		List<ProductMaster> list = new ArrayList<ProductMaster>();

		try {
			Connection con = KitDao.getConnection();
			String sql = "select * from ProductList";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				ProductMaster products = new ProductMaster();
				products.setId(rs.getInt("Product_ID"));
				products.setProductName(rs.getString("ProductName"));
				products.setCost(rs.getInt("Cost"));
				products.setProductdescription(rs.getString("ProductDescription"));
				products.setQuantity(rs.getInt("quantity"));
				products.setTotal(rs.getFloat("total"));
				
				list.add(products);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	/*
	 * protected void disconnect() throws SQLException { if (jdbcConnection != null
	 * && !jdbcConnection.isClosed()) { jdbcConnection.close(); } }
	 */

}
