package coronakit.model;

import java.util.ArrayList;

public class KitDetail {

	private int itemno;
	private String itemname;
	private int TotalCost;
	public int getTotalCost() {
        return TotalCost;
    }
    public void setTotalCost(int TotalCost) {
        this.TotalCost = TotalCost;
    }
	

	
	public int getItemno() {
		return itemno;
	}

	public void setItemno(int itemno) {
		this.itemno = itemno;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	  
	
	
	
	public KitDetail() {
		
		super();
		// TODO Auto-generated constructor stub
	}

	
}
