package coronakit.dao;

public class Products {

}
