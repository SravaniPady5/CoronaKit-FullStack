package coronakit.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import coronakit.dao.KitDao;
import coronakit.model.KitDetail;
import coronakit.model.ProductMaster;

/**
 * Servlet implementation class addtoCart
 */
@WebServlet("/addtoCart")
public class addtoCart extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public addtoCart() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String id = request.getParameter("id");
		int itemno = Integer.parseInt(id);
		/*
		 * HttpSession session = request.getSession(); int quantity=
		 * (int)session.getAttribute("s");
		 */
		String quantity = request.getParameter("quantity");
		int productquantity = Integer.parseInt(quantity);

		String p_name = request.getParameter("productanme");
		String price = request.getParameter("cost");
		int cost = Integer.parseInt(price);
		
		 String total=request.getParameter("total"); 
		 System.out.println("total is"+total);
		 float t=Float.parseFloat(total);
		// float total1=Float.parseFloat("total");
		 
		int status = KitDao.addToCart(itemno, p_name, cost, productquantity);
		
		
		KitDetail Kd=new KitDetail();
		
		if (status == 1)

		{
			try {

				List<ProductMaster> products = KitDao.getAllProducts();
				request.setAttribute("products", products);
				RequestDispatcher dispatcher = request.getRequestDispatcher("KitDetail.jsp");
				dispatcher.forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

	}

}
