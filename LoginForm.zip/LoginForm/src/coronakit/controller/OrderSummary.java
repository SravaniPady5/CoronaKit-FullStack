package coronakit.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import coronakit.dao.KitDao;
import coronakit.model.ProductMaster;

/**
 * Servlet implementation class OrderSummary
 */
@WebServlet("/OrderSummary")
public class OrderSummary extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderSummary() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		try {

			/*
			 * List<ProductMaster> products1 = KitDao.getAllProducts();
			 * request.setAttribute("products", products1);
			 */
			ProductMaster m=new ProductMaster();
			float total=m.getTotalcost();
			System.out.println(total);
			Object totalcost=(float)total;
			request.setAttribute("Totalcost", totalcost);
			RequestDispatcher dispatcher = request.getRequestDispatcher("OrderSummary.jsp");
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		
	}

}
